package com.example.mutiplescreens;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button star_a =(Button) findViewById(R.id.star_a);
        star_a.setOnClickListener(new View.OnClickListener(){
                                      @Override

                                      public void onClick(View v){
                                          Intent startIntent = new Intent(getApplicationContext(), SecondActivity.class);
                                          startIntent.putExtra("org.mentorschools.quicklauncher.SOMETHING","Hie Grade 6 Class, Welcome to the the Interferometer Lesson");
                                          startActivity(startIntent);
                                      }
                                  });



        Button star_b =(Button) findViewById(R.id.star_b);
        star_b.setOnClickListener(new View.OnClickListener(){
            @Override

            public void onClick(View v){
                Intent startIntent = new Intent(getApplicationContext(), SecondActivity.class);
                startIntent.putExtra("org.mentorschools.quicklauncher.SOMETHING","Hie Grade 7 Class, Welcome to the the Interferometer Lesson");
                startActivity(startIntent);
            }
        });


    }

    // Animate buttons
    public void tapToAnimate(View view) {
        Button star_b =(Button)findViewById(R.id.star_b);
        final Animation animation = AnimationUtils.loadAnimation(this, R.anim.bounce);
        star_b.startAnimation(animation);
    }

    public void tapToAnimate2(View view) {
        Button star_a =(Button)findViewById(R.id.star_a);
        final Animation animation = AnimationUtils.loadAnimation(this, R.anim.bounce);
        star_a.startAnimation(animation);
    }

    public void tapToAnimate3(View view) {
        Button title =(Button)findViewById(R.id.title);
        final Animation animation = AnimationUtils.loadAnimation(this, R.anim.bounce);
        title.startAnimation(animation);
    }
}
