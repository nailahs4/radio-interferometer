package com.example.quiztemp;

public class Questions {

    public String mQuestions[] ={
            "What is the name of the first month of the year?",
            "What is the name of the second month of the year?",
            "What is the name of the third  month of the year?",
            "What is the name of the fourth month of the year?",
            "What is the name of the fifth  month of the year?",
            "What is the name of the sixth  month of the year?",
            "What is the name of the seventh  month of the year?",
            "What is the name of the eighth  month of the year?",
            "What is the name of the ninth  month of the year?",
    };

    private String mChoices[][]={

            {"January", "Venus", "Mars", "Saturn"},
            {"Jupiter", "February", "Earth", "Neptune"},
            {"March", "Jupiter", "Pluto", "Venus"},
            {"Jupiter", "Saturn", "April", "Earth"},
            {"May", "Pluto", "Mercury", "Earth"},
            {"Uranus", "Venus", "Mars", "June"},
            {"Saturn", "Pluto", "July", "Earth"},
            {"Venus", "August", "Pluto", "Mars"},
            {"Mercury", "Venus", "Mars", "September"}

    };

    private String mCorrectAnswers[]= {"January", "February", "March", "April", "May", "June", "July", "August", "September"};

    public String getQuestion(int a){
        String question = mQuestions[a];
        return question;
    }

    public String getChoice1(int a){
        String choice= mChoices[a][0];
        return choice;
    }

    public String getChoice2(int a){
        String choice= mChoices[a][1];
        return choice;
    }

    public String getChoice3(int a){
        String choice= mChoices[a][2];
        return choice;
    }

    public String getChoice4(int a){
        String choice= mChoices[a][3];
        return choice;
    }

    public String getCorrectAnswer(int a){
        String answer =mCorrectAnswers[a];
        return answer;

    }
}
